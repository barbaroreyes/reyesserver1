// controllers/bookingController.js

const Booking = require('../models/Booking');
const { sendConfirmationEmail } = require('../utils/email');

exports.createBooking = async (req, res) => {
    try {
        const booking = await Booking.create(req.body);
        await sendConfirmationEmail(req.body.email, req.body);
        console.log('Booking created:', booking);
        res.status(201).json({ success: true, data: booking });
    } catch (error) {
        console.error('Error creating booking:', error);
        res.status(500).json({ success: false, error: 'Server error' });
    }
};

exports.getAll = async (req, res) =>{
    try {
        const count = await Booking.countDocuments();
        res.status(200).json({ count });
    } catch (error) {
        console.error('Error fetching booking count:', error);
        res.status(500).json({ error: 'Server error' });
    }
}