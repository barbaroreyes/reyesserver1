// utils/email.js
const nodemailer = require('nodemailer');
require('dotenv').config();

// Create a transporter object using SMTP transport
const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: false, // true for 465, false for other ports
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

// Function to send email confirmation
const sendConfirmationEmail = async (email, bookingDetails) => {
    try {
        // Send mail with defined transport object
        await transporter.sendMail({
            from: `"Reyes Luxury Cars" <${process.env.EMAIL_USER}>`,
            to: [email,process.env.EMAIL_US],
            subject: 'Booking Confirmation',
            html: `<p>
            We are thrilled to inform you that your ride has been successfully reserved with our transportation service. We appreciate you choosing us for your 
            transportation needs and are excited to provide you with a seamless and comfortable experience.
            Thank you for booking a ride with Reyes Luxury Cars!</p>


                   <p>Your booking details:</p>
                   <ul>
                       <li>Name: ${bookingDetails.name}</li>
                       <li>Email: ${bookingDetails.email}</li>
                       <li>Date: ${bookingDetails.pickupDate}</li>
                       <li>Time: ${bookingDetails.time}</li>
                       <li>Pickup Location: ${bookingDetails.pickupLocation}</li>
                       <li>Dropoff Location: ${bookingDetails.dropoffLocation}</li>
                       <li>Price: ${bookingDetails.price}</li>
                       <h3>You can make your payment after we have implemted  all ways ( paypal Zell Vemmo Cash Square devit/credit cash) </h3>
                   </ul>
                   <p>We look forward to serving you!</p>`,
        });
        console.log('Email sent successfully');
    } catch (error) {
        console.error('Error sending email:', error);
        throw new Error('Error sending email');
    }
};

module.exports = { sendConfirmationEmail };
