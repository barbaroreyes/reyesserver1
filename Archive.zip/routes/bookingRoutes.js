// routes/bookingRoutes.js
const express = require('express');
const router = express.Router();
const { createBooking ,getAll} = require('../controllers/bookingController');


router.post('/bookings', createBooking);
router.get('/count', getAll);




module.exports = router;