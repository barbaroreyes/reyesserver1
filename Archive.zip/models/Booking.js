// models/Booking.js
const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String,  required: true },
    phone:{type:Number},
    pickupLocation: { type: String, required: true },
    pickupDate:{type: Date, required: true},
    time:{type: String, required: true},
    dropoffLocation: { type: String, required: true },
    passagers:{type:String ,required: true},
    rideType:{type: String, required: true},
    price:{type:String},

    distance:{type:String},
   createdAt: { type: Date, default: Date.now }
});

const Booking = mongoose.model('Booking', bookingSchema);

module.exports = Booking;
